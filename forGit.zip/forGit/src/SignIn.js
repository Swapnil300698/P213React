import { useState } from "react";

function SignIn(){
     var [name, setName] = useState("");
     var change = ()=>{
       setName("Rajendra");
     }
     var [stu,setStu] = useState({id:3,sName:"Sakshi",city:'Dhule'});
    
     var chStu = () =>{
     setStu({id:1,sName:"Mayuree",city:"Sambhajinagar"});
     }
    return (
        <div>
            <h1>Hello from  SignIn {name}</h1>
            <button onClick={change}>Change</button>
            <div>
                <h2>{stu.id}</h2>
                <h2>{stu.sName}</h2>
                <h3>{stu.city}</h3>
                <button onClick={chStu}>Update</button>
            </div>
        </div>
    )
}
export default SignIn;