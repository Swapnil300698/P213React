import { Link, useNavigate } from "react-router-dom";
import "./Navbar.css";
function Navbar(){
    var navigate = useNavigate();
    var run = ()=>{
        navigate("/login");
    }
    return (
        <div className="n">
            <Link to="/home" className="l">Home</Link>
            <Link to="/about" className="l">About</Link>
            <Link to="/login" className="l">Login</Link>
            <Link to="/signup" className="l">SignUp</Link>
            <button onClick={run} className="l">Submit</button>
        </div>
    )
}
export default Navbar;