import {Component } from "react";
import React from "react";
class MyClass extends React.Component{
      x =30;
      constructor(props){
        super(props);
        this.state = {
            sName:"Rajendra",
            city:"Solapur"
        }
      }
      change(){
        this.setState({sName:"Sakshi",city:"Dhule"})
      }
    render(){
        return(
            <div>
               <h1>Hello from MyClass Component  {this.x}</h1>
               <h1>{this.props.name}</h1>
               <h1>{this.state.sName}</h1>
               <button onClick={()=>{this.change()}}>Change</button>
            </div>
        )
    }
}
export default MyClass;