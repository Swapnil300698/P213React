import { useState } from "react";
import "./Navbar.css";

function Login(){
    var [u,setU] = useState("");
    var [p,setP] = useState("");
    var first = (e)=>{
       setU(e.target.value);
      
    }
    var second=(e)=>{
       setP(e.target.value);
    }
    return (
        <div className="lo">
            <h1>Hello from Login</h1>
            <input type="text" onChange={first}/>
            <input type="text" onChange={second}/>
            <h1> {u}</h1>
            <h2>{p}</h2>
        </div>
    )
}
export default  Login