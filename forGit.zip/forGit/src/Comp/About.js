
import "./Navbar.css";
function About(){
    var a = 300;
    var b = 330;
    var c= "";
    return (
        <div className="a">
            <h1>Hello from About</h1>
            <div>
                {a==b && <h1>Hello from AND</h1>}

                {c || <h1>Loading.....</h1>}

                {a==b ?  <h1>Hello from IF</h1>:<h1>Hello from ELSE</h1>}

            </div>
        </div>
    )
}
export default About;