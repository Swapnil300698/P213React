import { BrowserRouter, Route, Routes } from 'react-router-dom';
import './App.css';
import Navbar from './Comp/Navbar';
import Home from './Comp/Home';
import About from './Comp/About';
import Login from './Comp/Login';
import SignUp from './Comp/SignUp';
import MyClass from './Comp/MyClass';
function App() {
    
  return (
      <div>
         <MyClass name="Sohel"/>
      </div>
  );
}

export default App;
