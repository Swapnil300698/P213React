import "./Student.css";
function Student(prop){

  return(
    <div className="c">
        <h1>Hello from Student</h1>
       
        <h2>{prop.name}</h2>
        <h2>{prop.city}</h2>
        <h2>{prop.email}</h2>
    </div>
  )
}
export default Student;