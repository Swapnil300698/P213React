import { useState } from "react";
import "./Concepts.css";
function Concepts(){
     
      var [obj, setObj] = useState({backgroundColor:"red",height:"200px"});
      var change = ()=>{
         setObj({backgroundColor:"green",height:"100px"});
      }
    return(
       <div>
        <h1 style={obj}>Hello from Concepts</h1>
        <button onClick={change}>Change</button>
        <h2 className="abc">Hello from h2</h2>
       </div>
    )
}
export default Concepts;