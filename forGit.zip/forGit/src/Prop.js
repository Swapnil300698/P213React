 function Props(){
     var name = "Rushikesh";
    var num = 234;
    var arr =[12,23,45,66,88,99,23,33];
    function fun(){
      var n = " Sohel";
      return n;
    }
    var oArr = [{id:1,sname: "sohel",city:"pune"},
      {id:2,sname: "Anuja",city:"Ahilyanagar"},
      {id:3,sname: "Rajshree",city:"Mumbai"}];

    return (
        <div>
       
           <h1> {num} Hello from {fun()} Fisrt App  {name}</h1>
        <input type="text"/>

        <div>
          {oArr.map((s)=>{
            return (
              <div>
                  <h1>{s.id}</h1>
                  <h1>{s.sname}</h1>
                  <h1>{s.city}</h1>
              </div>
            )
          })};
        </div>
        </div>
    )
 }
 export default Props;